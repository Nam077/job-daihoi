<?php
echo '<div class="left">';
echo '<ul class="main-menu__list">';
echo '<li class="dropdown">';
echo '<a href="index.php">Trang chủ</a>';
echo '</li>';
echo '<li class="current"><a href="index.php#document">Tài liệu</a></li>';
echo '<li class="current"><a href="attendance.php#sodo">Sơ đồ chỗ ngồi</a></li>';
echo '<li class="current"><a href="attendance.php">Điểm danh</a></li>';
echo '</ul>';
echo '</div>';
